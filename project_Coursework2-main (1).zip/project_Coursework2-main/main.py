# main.py
from gui import WarehouseApp
import tkinter as tk

if __name__ == "__main__":
    root = tk.Tk()
    app = WarehouseApp(root)
    root.mainloop()