import sqlite3
from datetime import datetime

def create_database():
    """Создание базы данных и таблиц."""
    conn = sqlite3.connect('warehouse.db')
    cursor = conn.cursor()

    cursor.execute('''
        CREATE TABLE IF NOT EXISTS products (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            article TEXT UNIQUE,
            name TEXT,
            category TEXT,
            manufacturer TEXT,
            weight REAL,
            dimensions TEXT,
            price REAL,
            quantity INTEGER,
            image_path TEXT
        )
    ''')

    cursor.execute('''
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE,
            password TEXT,
            role TEXT
        )
    ''')

    cursor.execute('''
        CREATE TABLE IF NOT EXISTS invoices (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            type TEXT,
            product_id INTEGER,
            quantity INTEGER,
            date TEXT,
            user_id INTEGER,
            FOREIGN KEY(product_id) REFERENCES products(id),
            FOREIGN KEY(user_id) REFERENCES users(id)
        )
    ''')

    # Добавление пользователей по умолчанию
    cursor.execute("INSERT OR IGNORE INTO users (username, password, role) VALUES ('admin', 'admin', 'admin')")
    cursor.execute("INSERT OR IGNORE INTO users (username, password, role) VALUES ('user', 'user', 'user')")

    conn.commit()
    conn.close()

# Создание базы данных при первом запуске
create_database()

def authenticate_user(username, password):
    """Аутентификация пользователя."""
    conn = sqlite3.connect('warehouse.db')
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM users WHERE username = ? AND password = ?", (username, password))
    user = cursor.fetchone()
    conn.close()
    return user

def get_all_products():
    """Получение всех товаров."""
    conn = sqlite3.connect('warehouse.db')
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM products")
    products = cursor.fetchall()
    conn.close()
    return products

def get_product_by_id(product_id):
    """Получение товара по ID."""
    conn = sqlite3.connect('warehouse.db')
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM products WHERE id = ?", (product_id,))
    product = cursor.fetchone()
    conn.close()
    return product

def search_products(query):
    """Поиск товаров."""
    conn = sqlite3.connect('warehouse.db')
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM products WHERE name LIKE ? OR article LIKE ?", (f"%{query}%", f"%{query}%"))
    products = cursor.fetchall()
    conn.close()
    return products

def add_product(article, name, category, manufacturer, weight, dimensions, price, quantity, image_path):
    """Добавление нового товара."""
    conn = sqlite3.connect('warehouse.db')
    cursor = conn.cursor()
    cursor.execute('''
        INSERT INTO products (article, name, category, manufacturer, weight, dimensions, price, quantity, image_path)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    ''', (article, name, category, manufacturer, weight, dimensions, price, quantity, image_path))
    conn.commit()
    conn.close()

def update_product(product_id, article, name, category, manufacturer, weight, dimensions, price, quantity, image_path):
    """Обновление данных товара."""
    conn = sqlite3.connect('warehouse.db')
    cursor = conn.cursor()
    cursor.execute('''
        UPDATE products
        SET article = ?, name = ?, category = ?, manufacturer = ?, weight = ?, dimensions = ?, price = ?, quantity = ?, image_path = ?
        WHERE id = ?
    ''', (article, name, category, manufacturer, weight, dimensions, price, quantity, image_path, product_id))
    conn.commit()
    conn.close()

def delete_product(product_id):
    """Удаление товара."""
    conn = sqlite3.connect('warehouse.db')
    cursor = conn.cursor()
    cursor.execute("DELETE FROM products WHERE id = ?", (product_id,))
    conn.commit()
    conn.close()

def get_all_invoices():
    """Получение всех накладных."""
    conn = sqlite3.connect('warehouse.db')
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM invoices")
    invoices = cursor.fetchall()
    conn.close()
    return invoices

def add_invoice(invoice_type, product_id, quantity, user_id):
    """Добавление новой накладной."""
    conn = sqlite3.connect('warehouse.db')
    cursor = conn.cursor()
    date = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    cursor.execute('''
        INSERT INTO invoices (type, product_id, quantity, date, user_id)
        VALUES (?, ?, ?, ?, ?)
    ''', (invoice_type, product_id, quantity, date, user_id))
    conn.commit()
    conn.close()

def delete_invoice(invoice_id):
    """Удаление накладной."""
    conn = sqlite3.connect('warehouse.db')
    cursor = conn.cursor()
    cursor.execute("DELETE FROM invoices WHERE id = ?", (invoice_id,))
    conn.commit()
    conn.close()

def get_product_id_by_name(article):
    """Получение ID товара по артикулу."""
    conn = sqlite3.connect('warehouse.db')
    cursor = conn.cursor()
    cursor.execute("SELECT id FROM products WHERE article = ?", (article,))
    product_id = cursor.fetchone()
    conn.close()
    return product_id[0] if product_id else None