# database.py
import sqlite3
import os

def create_database():
    """Создание базы данных и таблиц."""
    if not os.path.exists('warehouse.db'):
        conn = sqlite3.connect('warehouse.db')
        cursor = conn.cursor()

        # Создание таблицы товаров
        cursor.execute('''
            CREATE TABLE products (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                article TEXT UNIQUE,
                name TEXT,
                category TEXT,
                manufacturer TEXT,
                weight REAL,
                dimensions TEXT,
                price REAL,
                quantity INTEGER,
                image_path TEXT
            )
        ''')

        # Создание таблицы пользователей
        cursor.execute('''
            CREATE TABLE users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT UNIQUE,
                password TEXT,
                role TEXT
            )
        ''')

        # Создание таблицы накладных
        cursor.execute('''
            CREATE TABLE invoices (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                type TEXT,
                product_id INTEGER,
                quantity INTEGER,
                date TEXT,
                user_id INTEGER,
                FOREIGN KEY(product_id) REFERENCES products(id),
                FOREIGN KEY(user_id) REFERENCES users(id)
            )
        ''')

        # Добавление пользователей по умолчанию
        cursor.execute("INSERT INTO users (username, password, role) VALUES ('admin', 'admin', 'admin')")
        cursor.execute("INSERT INTO users (username, password, role) VALUES ('user', 'user', 'user')")

        conn.commit()
        conn.close()

# Создание базы данных при первом запуске
create_database()