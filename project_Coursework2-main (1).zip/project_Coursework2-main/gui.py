import tkinter as tk
from tkinter import ttk, messagebox, filedialog
from PIL import Image, ImageTk
import logic
from datetime import datetime

class WarehouseApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Управление складским учетом")
        self.root.geometry("1200x800")
        self.root.configure(bg="#4B0082")  # Темно-фиолетовый фон

        # Стилизация
        self.style = ttk.Style()
        self.style.theme_use("clam")
        self.configure_styles()

        # Текущий пользователь
        self.current_user = None

        # Создание интерфейса
        self.create_login_screen()

    def configure_styles(self):
        """Настройка стилей для интерфейса."""
        self.style.configure("TFrame", background="#4B0082")
        self.style.configure("TLabel", background="#4B0082", foreground="#FFFFFF", font=("Segoe UI", 12))
        self.style.configure("TButton", background="#8A2BE2", foreground="#FFFFFF", font=("Segoe UI", 12), padding=10, borderwidth=0)
        self.style.map("TButton", background=[("active", "#A881AF")])
        self.style.configure("TEntry", fieldbackground="#A881AF", foreground="#000000", font=("Segoe UI", 12), padding=5)
        self.style.configure("Treeview", background="#A881AF", foreground="#FFFFFF", fieldbackground="#A881AF", font=("Segoe UI", 12))
        self.style.map("Treeview", background=[("selected", "#8A2BE2")])

    def create_login_screen(self):
        """Создание экрана авторизации."""
        self.clear_screen()

        login_frame = ttk.Frame(self.root, style="TFrame")
        login_frame.place(relx=0.5, rely=0.5, anchor="center")

        ttk.Label(login_frame, text="Логин:", style="TLabel").pack(pady=5)
        self.username_entry = ttk.Entry(login_frame, style="TEntry")
        self.username_entry.pack(pady=5)

        ttk.Label(login_frame, text="Пароль:", style="TLabel").pack(pady=5)
        self.password_entry = ttk.Entry(login_frame, show="*", style="TEntry")
        self.password_entry.pack(pady=5)

        login_button = ttk.Button(login_frame, text="Войти", style="TButton", command=self.login)
        login_button.pack(pady=10)

    def login(self):
        """Обработка входа пользователя."""
        username = self.username_entry.get()
        password = self.password_entry.get()

        user = logic.authenticate_user(username, password)
        if user:
            self.current_user = user
            self.create_main_screen()
        else:
            messagebox.showerror("Ошибка", "Неверный логин или пароль")

    def create_main_screen(self):
        """Создание главного экрана."""
        self.clear_screen()

        # Боковое меню
        sidebar = ttk.Frame(self.root, width=200, style="TFrame")
        sidebar.pack(side="left", fill="y")

        # Кнопки меню
        btn_products = ttk.Button(sidebar, text="Товары", style="TButton", command=self.show_products)
        btn_products.pack(pady=10, fill="x")

        btn_invoices = ttk.Button(sidebar, text="Накладные", style="TButton", command=self.show_invoices)
        btn_invoices.pack(pady=10, fill="x")

        btn_manual = ttk.Button(sidebar, text="Руководство", style="TButton", command=self.show_manual)
        btn_manual.pack(pady=10, fill="x")

        # Основное содержимое
        self.main_content = ttk.Frame(self.root, style="TFrame")
        self.main_content.pack(side="right", fill="both", expand=True)

        # Отображение товаров по умолчанию
        self.show_products()

    def show_products(self):
        """Отображение списка товаров."""
        self.clear_main_content()

        # Панель поиска
        search_frame = ttk.Frame(self.main_content, style="TFrame")
        search_frame.pack(fill="x", padx=10, pady=10)

        self.search_entry = ttk.Entry(search_frame, style="TEntry")
        self.search_entry.pack(side="left", fill="x", expand=True, padx=5)

        search_button = ttk.Button(search_frame, text="Поиск", style="TButton", command=self.search_products)
        search_button.pack(side="left", padx=5)

        # Таблица товаров
        columns = ("id", "Артикул", "Название", "Категория", "Количество")
        self.tree = ttk.Treeview(self.main_content, columns=columns, show="headings", style="Treeview")
        self.tree.column("id", width=0, stretch=tk.NO)  # Скрытый столбец ID
        for col in columns[1:]:
            self.tree.heading(col, text=col)
        self.tree.pack(fill="both", expand=True, padx=10, pady=10)

        # Загрузка данных
        self.load_products()

        # Кнопки управления (только для администратора)
        if self.current_user[3] == "admin":
            button_frame = ttk.Frame(self.main_content, style="TFrame")
            button_frame.pack(fill="x", padx=10, pady=10)

            btn_add = ttk.Button(button_frame, text="Добавить товар", style="TButton", command=self.show_product_form)
            btn_add.pack(side="left", padx=5)

            btn_edit = ttk.Button(button_frame, text="Редактировать товар", style="TButton", command=self.edit_product)
            btn_edit.pack(side="left", padx=5)

            btn_delete = ttk.Button(button_frame, text="Удалить товар", style="TButton", command=self.delete_product)
            btn_delete.pack(side="left", padx=5)

    def load_products(self):
        """Загрузка товаров из базы данных."""
        self.tree.delete(*self.tree.get_children())  # Очистка таблицы перед загрузкой
        products = logic.get_all_products()
        for product in products:
            self.tree.insert("", "end", values=(product[0], product[1], product[2], product[3], product[7]))

    def search_products(self):
        """Поиск товаров."""
        query = self.search_entry.get()
        products = logic.search_products(query)
        self.tree.delete(*self.tree.get_children())
        for product in products:
            self.tree.insert("", "end", values=(product[0], product[1], product[2], product[3], product[7]))

    def show_product_form(self, product=None):
        """Отображение формы для добавления/редактирования товара."""
        if self.current_user[3] != "admin":
            messagebox.showwarning("Ошибка", "У вас нет прав для редактирования товаров")
            return

        self.clear_main_content()

        form_frame = ttk.Frame(self.main_content, style="TFrame")
        form_frame.pack(fill="both", expand=True, padx=10, pady=10)

        fields = [
            ("Артикул", "entry_article"),
            ("Название", "entry_name"),
            ("Категория", "entry_category"),
            ("Производитель", "entry_manufacturer"),
            ("Вес", "entry_weight"),
            ("Габариты", "entry_dimensions"),
            ("Стоимость", "entry_price"),
            ("Количество", "entry_quantity"),
        ]

        for i, (label_text, field_name) in enumerate(fields):
            ttk.Label(form_frame, text=label_text, style="TLabel").grid(row=i, column=0, padx=5, pady=5)
            entry = ttk.Entry(form_frame, style="TEntry")
            entry.grid(row=i, column=1, padx=5, pady=5)
            setattr(self, field_name, entry)

        # Загрузка изображения
        ttk.Button(form_frame, text="Загрузить изображение", style="TButton", command=self.load_image).grid(row=len(fields), column=0, columnspan=2, pady=10)
        self.label_image_path = ttk.Label(form_frame, text="", style="TLabel")
        self.label_image_path.grid(row=len(fields) + 1, column=0, columnspan=2)
        self.label_image = ttk.Label(form_frame)
        self.label_image.grid(row=len(fields) + 2, column=0, columnspan=2)

        # Кнопки
        if product:
            self.load_product_data(product)
            ttk.Button(form_frame, text="Сохранить", style="TButton", command=lambda: self.update_product(product)).grid(row=len(fields) + 3, column=0, columnspan=2, pady=10)
        else:
            ttk.Button(form_frame, text="Добавить", style="TButton", command=self.add_product).grid(row=len(fields) + 3, column=0, columnspan=2, pady=10)

    def load_image(self):
        """Загрузка изображения для товара."""
        file_path = filedialog.askopenfilename()
        if file_path:
            self.label_image_path.config(text=file_path)
            image = Image.open(file_path)
            image.thumbnail((200, 200))
            photo = ImageTk.PhotoImage(image)
            self.label_image.config(image=photo)
            self.label_image.image = photo

    def add_product(self):
        """Добавление нового товара."""
        article = self.entry_article.get()
        name = self.entry_name.get()
        category = self.entry_category.get()
        manufacturer = self.entry_manufacturer.get()
        weight = self.entry_weight.get()
        dimensions = self.entry_dimensions.get()
        price = self.entry_price.get()
        quantity = self.entry_quantity.get()
        image_path = self.label_image_path["text"]

        if not article or not name:
            messagebox.showerror("Ошибка", "Заполните обязательные поля: Артикул и Название")
            return

        logic.add_product(article, name, category, manufacturer, weight, dimensions, price, quantity, image_path)
        messagebox.showinfo("Успех", "Товар добавлен")
        self.show_products()

    def load_product_data(self, product):
        """Загрузка данных товара в форму."""
        self.entry_article.insert(0, product[1])
        self.entry_name.insert(0, product[2])
        self.entry_category.insert(0, product[3])
        self.entry_manufacturer.insert(0, product[4])
        self.entry_weight.insert(0, product[5])
        self.entry_dimensions.insert(0, product[6])
        self.entry_price.insert(0, product[7])
        self.entry_quantity.insert(0, product[8])
        if product[9]:
            self.label_image_path.config(text=product[9])
            image = Image.open(product[9])
            image.thumbnail((200, 200))
            photo = ImageTk.PhotoImage(image)
            self.label_image.config(image=photo)
            self.label_image.image = photo

    def update_product(self, product):
        """Обновление данных товара."""
        article = self.entry_article.get()
        name = self.entry_name.get()
        category = self.entry_category.get()
        manufacturer = self.entry_manufacturer.get()
        weight = self.entry_weight.get()
        dimensions = self.entry_dimensions.get()
        price = self.entry_price.get()
        quantity = self.entry_quantity.get()
        image_path = self.label_image_path["text"]

        logic.update_product(product[0], article, name, category, manufacturer, weight, dimensions, price, quantity, image_path)
        messagebox.showinfo("Успех", "Товар обновлен")
        self.show_products()

    def delete_product(self):
        """Удаление товара."""
        if self.current_user[3] != "admin":
            messagebox.showwarning("Ошибка", "У вас нет прав для удаления товаров")
            return

        selected_item = self.tree.selection()
        if not selected_item:
            messagebox.showerror("Ошибка", "Выберите товар для удаления")
            return

        product_id = self.tree.item(selected_item, "values")[0]
        if messagebox.askyesno("Подтверждение", "Вы уверены, что хотите удалить товар?"):
            logic.delete_product(product_id)
            messagebox.showinfo("Успех", "Товар удален")
            self.load_products()  # Обновляем таблицу после удаления

    def edit_product(self):
        """Редактирование товара."""
        if self.current_user[3] != "admin":
            messagebox.showwarning("Ошибка", "У вас нет прав для редактирования товаров")
            return

        selected_item = self.tree.selection()
        if not selected_item:
            messagebox.showerror("Ошибка", "Выберите товар для редактирования")
            return

        product_id = self.tree.item(selected_item, "values")[0]
        product = logic.get_product_by_id(product_id)
        self.show_product_form(product)

    def show_invoices(self):
        """Отображение накладных."""
        self.clear_main_content()

        # Панель поиска
        search_frame = ttk.Frame(self.main_content, style="TFrame")
        search_frame.pack(fill="x", padx=10, pady=10)

        self.search_entry_invoices = ttk.Entry(search_frame, style="TEntry")
        self.search_entry_invoices.pack(side="left", fill="x", expand=True, padx=5)

        search_button = ttk.Button(search_frame, text="Поиск", style="TButton", command=self.search_invoices)
        search_button.pack(side="left", padx=5)

        # Таблица накладных
        columns = ("id", "Тип", "Товар", "Количество", "Дата")
        self.tree_invoices = ttk.Treeview(self.main_content, columns=columns, show="headings", style="Treeview")
        self.tree_invoices.column("id", width=0, stretch=tk.NO)  # Скрытый столбец ID
        for col in columns[1:]:
            self.tree_invoices.heading(col, text=col)
        self.tree_invoices.pack(fill="both", expand=True, padx=10, pady=10)

        # Загрузка данных
        self.load_invoices()

        # Кнопки управления (только для администратора)
        if self.current_user[3] == "admin":
            btn_add = ttk.Button(self.main_content, text="Добавить накладную", style="TButton", command=self.show_invoice_form)
            btn_add.pack(pady=10)

            btn_delete = ttk.Button(self.main_content, text="Удалить накладную", style="TButton", command=self.delete_invoice)
            btn_delete.pack(pady=10)

    def load_invoices(self):
        """Загрузка накладных из базы данных."""
        self.tree_invoices.delete(*self.tree_invoices.get_children())  # Очистка таблицы перед загрузкой
        invoices = logic.get_all_invoices()
        for invoice in invoices:
            self.tree_invoices.insert("", "end", values=(invoice[0], invoice[1], invoice[2], invoice[3], invoice[4]))

    def search_invoices(self):
        """Поиск накладных."""
        query = self.search_entry_invoices.get()
        invoices = logic.search_invoices(query)
        self.tree_invoices.delete(*self.tree_invoices.get_children())
        for invoice in invoices:
            self.tree_invoices.insert("", "end", values=(invoice[0], invoice[1], invoice[2], invoice[3], invoice[4]))

    def show_invoice_form(self):
        """Отображение формы для добавления накладной."""
        if self.current_user[3] != "admin":
            messagebox.showwarning("Ошибка", "У вас нет прав для добавления накладных")
            return

        self.clear_main_content()

        form_frame = ttk.Frame(self.main_content, style="TFrame")
        form_frame.pack(fill="both", expand=True, padx=10, pady=10)

        ttk.Label(form_frame, text="Тип накладной:", style="TLabel").grid(row=0, column=0, padx=5, pady=5)
        self.combo_type = ttk.Combobox(form_frame, values=["Приходная", "Расходная"], style="TEntry")
        self.combo_type.grid(row=0, column=1, padx=5, pady=5)

        ttk.Label(form_frame, text="Товар:", style="TLabel").grid(row=1, column=0, padx=5, pady=5)
        self.combo_product = ttk.Combobox(form_frame, style="TEntry")
        self.combo_product.grid(row=1, column=1, padx=5, pady=5)

        ttk.Label(form_frame, text="Количество:", style="TLabel").grid(row=2, column=0, padx=5, pady=5)
        self.entry_quantity = ttk.Entry(form_frame, style="TEntry")
        self.entry_quantity.grid(row=2, column=1, padx=5, pady=5)

        # Загрузка списка товаров
        products = logic.get_all_products()
        self.combo_product["values"] = [f"{product[1]} ({product[2]})" for product in products]

        # Кнопка добавления
        ttk.Button(form_frame, text="Добавить накладную", style="TButton", command=self.add_invoice).grid(row=3, column=0, columnspan=2, pady=10)

    def add_invoice(self):
        """Добавление новой накладной."""
        if self.current_user[3] != "admin":
            messagebox.showwarning("Ошибка", "У вас нет прав для добавления накладных")
            return

        invoice_type = self.combo_type.get()
        product_name = self.combo_product.get()
        quantity = self.entry_quantity.get()

        if not invoice_type or not product_name or not quantity:
            messagebox.showerror("Ошибка", "Заполните все поля")
            return

        # Получение ID товара
        product_id = logic.get_product_id_by_name(product_name.split(" (")[0])
        if not product_id:
            messagebox.showerror("Ошибка", "Товар не найден")
            return

        logic.add_invoice(invoice_type, product_id, quantity, self.current_user[0])
        messagebox.showinfo("Успех", "Накладная добавлена")
        self.show_invoices()

    def delete_invoice(self):
        """Удаление накладной."""
        if self.current_user[3] != "admin":
            messagebox.showwarning("Ошибка", "У вас нет прав для удаления накладных")
            return

        selected_item = self.tree_invoices.selection()
        if not selected_item:
            messagebox.showerror("Ошибка", "Выберите накладную для удаления")
            return

        invoice_id = self.tree_invoices.item(selected_item, "values")[0]
        if messagebox.askyesno("Подтверждение", "Вы уверены, что хотите удалить накладную?"):
            logic.delete_invoice(invoice_id)
            messagebox.showinfo("Успех", "Накладная удалена")
            self.load_invoices()  # Обновляем таблицу после удаления

    def show_manual(self):
        """Отображение руководства пользователя."""
        manual_window = tk.Toplevel(self.root)
        manual_window.title("Руководство пользователя")
        manual_window.geometry("600x400")
        manual_window.configure(bg="#4B0082")

        text = tk.Text(manual_window, bg="#A881AF", fg="#FFFFFF", font=("Segoe UI", 12), wrap="word")
        text.pack(fill="both", expand=True, padx=10, pady=10)

        manual_text = """
        Добро пожаловать в руководство пользователя!

        1. Управление товарами:
           - Добавление: Заполните форму и нажмите "Добавить".
           - Редактирование: Выберите товар, измените данные и нажмите "Сохранить".
           - Удаление: Выберите товар и нажмите "Удалить".

        2. Накладные:
           - Приходные: Оформление поступления товаров.
           - Расходные: Оформление отгрузки товаров.

        3. Поиск:
           - Используйте поле поиска для быстрого нахождения товаров.

        4. Руководство:
           - Здесь вы найдете инструкции по использованию программы.
        """
        text.insert("end", manual_text)
        text.config(state="disabled")  # Запрет редактирования

    def clear_screen(self):
        """Очистка экрана."""
        for widget in self.root.winfo_children():
            widget.destroy()

    def clear_main_content(self):
        """Очистка основного содержимого."""
        for widget in self.main_content.winfo_children():
            widget.destroy()

if __name__ == "__main__":
    root = tk.Tk()
    app = WarehouseApp(root)
    root.mainloop()